<!DOCTYPE html>
<html lang="en" class="scroll-smooth">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Battery Monitoring System</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script src="https://kit.fontawesome.com/f3bc409a1d.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="w-full h-auto min-h-screen flex flex-col bg-center bg-cover bg-fixed"
        style="background-image: url('assets/bg.jpg')">
        
        <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('layout.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('layout.location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\main-project-bms\resources\views/layout/main.blade.php ENDPATH**/ ?>