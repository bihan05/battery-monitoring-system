<div class="w-full min-h-screen flex flex-col text-white">
    <div class="flex items-center flex-1">
        <div class="text-center mx-auto">
            <h1 class="text-5xl md:text-5xl lg:text-7xl font-bold">Battery Monitoring System</h1>
            <p class="font-medium text-xl md:text-xl lg:text-2xl mt-5">
                Digitalisasi monitoring baterai dengan teknologi IoT
            </p>
            <a href="#location"><i class="fa-solid fa-circle-chevron-down fa-2xl mt-20"></i></a>
        </div>
    </div>
</div>